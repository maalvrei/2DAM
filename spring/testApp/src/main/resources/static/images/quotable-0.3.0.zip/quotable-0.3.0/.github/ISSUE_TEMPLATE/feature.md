---
name: Feature
about: Suggest a new feature for the API
title: ''
labels: ":bulb: type: feature"
assignees: ''

---

## Description

Describe the feature you would like to add.
