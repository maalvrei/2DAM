---
name: Enhancement
about: Suggest changes to improve an existing endpoint
title: ''
labels: ":zap: type: enhancement"
assignees: ''

---

### Endpoints 

Which API endpoints would this change apply to. 

### Description 

How could we improve the specified endpoints
