import Quotes from './Quotes'
import Authors from './Authors'
import Tags from './Tags'

export default { Quotes, Authors, Tags }
