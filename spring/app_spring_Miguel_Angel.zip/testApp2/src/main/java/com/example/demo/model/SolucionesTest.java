package com.example.demo.model;

import java.util.ArrayList;

public class SolucionesTest {

	public ArrayList<Solucion> soluciones = new ArrayList<>();

	public ArrayList<Solucion> getSoluciones() {
		return soluciones;
	}

	public void setSoluciones(ArrayList<Solucion> soluciones) {
		this.soluciones = soluciones;
	}
	
}
