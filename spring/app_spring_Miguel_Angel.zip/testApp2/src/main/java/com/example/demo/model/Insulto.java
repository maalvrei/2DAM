package com.example.demo.model;

public class Insulto {

	private String insult;

	public String getInsult() {
		return insult;
	}

	public void setInsult(String insult) {
		this.insult = insult;
	}
	
	
	
}
